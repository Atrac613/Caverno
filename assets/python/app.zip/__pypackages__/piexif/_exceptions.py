class InvalidImageDataError(ValueError):
    pass
